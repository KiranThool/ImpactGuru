package com.org.seleniumbaseclass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseClass {

	public WebDriver getChromeDriver() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\kiran\\eclipse-workspace\\LambdaCertification\\Driver\\chromedriver.exe");
		WebDriver chromeDriver = new ChromeDriver();
		return chromeDriver;
	}

	public WebDriver getfirefoxDriver() {
		System.setProperty("webdriver.gecko.driver",
				"C://Users//kiran//Desktop//Software Testing//Driver//geckodriver-v0.29.1-win64/geckodriver");
		WebDriver firefoxDriver = new FirefoxDriver();
		return firefoxDriver;
	}

	public WebDriver getEdgeDriver() {
		System.setProperty("webdriver.edge.driver", "C://Users//kiran//Desktop//Software Testing//Driver//edgedriver_win64/msedgedriver");

		// Start Edge Session
		WebDriver Edgedriver = new EdgeDriver();
		return Edgedriver;
	}
	
}
