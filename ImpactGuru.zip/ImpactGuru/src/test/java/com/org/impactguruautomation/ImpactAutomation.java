package com.org.impactguruautomation;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.org.seleniumbaseclass.BaseClass;

public class ImpactAutomation extends BaseClass {

	private WebDriver driver;
	//	private WebElement everyMonthElement, customerServiceElement, , checkboxElement, sliderElement,
	//			jenkinsImageElement, imageUploadElement;
	//	private String actualPercentage, formattedOutput, toastMessageLocator, parentWindowHandle, childWindowHandle,
	//			jenkinsImageXpah, jenkinsImageURL, downloadedImageName, imageUploadCssLocator, downloadedImagePath;
	private WebDriverWait webDriverWait;
	private JavascriptExecutor javaScriptDriver;
	private WebElement FullName,Email,PhoneNumber,BillingCity,Updates;


	@BeforeClass
	public void beforeClass() {
		driver = getChromeDriver();
		driver.manage().window().maximize();

		webDriverWait = new WebDriverWait(driver, 5);
		javaScriptDriver = ((JavascriptExecutor) driver);

	}

	@Test
	public void loginTest() {
		/*
		 * Start by opening Imapact Guru Site from
		 *
		 */


		driver.get("https://staging.igstg.com/fundraiser/help-testdocumentchecklist");


		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElement(By.xpath("//*[@id=\"auth-local-btn\"]")).click();

		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("candidate");

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.MINUTES);

		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("igcandidate");

		driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();







		try {
			Thread.sleep(5000);
			driver.get("https://impactguru:8nvbil51pp@staging.igstg.com/fundraiser/help-testdocumentchecklist");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		WebDriverWait wait = new WebDriverWait(driver,1000);
		By DonateButton = By.xpath("//*[@id=\"cmp-nfr-exit-pop-up-donate\"]");
		wait.until(ExpectedConditions.elementToBeClickable(DonateButton));
		driver.findElement(DonateButton).click();
		
	}
	// Registration with all valid data
	@Test
	public void ValidateData() {

	
		WebDriverWait wait = new WebDriverWait(driver,1000);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"full_name\"]")));
		FullName=driver.findElement(By.xpath("//*[@id=\"full_name\"]"));
		FullName.sendKeys("Impact Guru");
		
		Email=driver.findElement(By.xpath("//*[@id=\"email_receipt\"]"));
    	Email.sendKeys("imapctguru@gmail.com");
    	
    	PhoneNumber=driver.findElement(By.xpath("//*[@id=\"mobile\"]"));
		PhoneNumber.sendKeys("1234567891");
		
		BillingCity=driver.findElement(By.xpath("//*[@id=\"city_text\"]"));
		BillingCity.sendKeys("Mumbai");
		
		Updates = driver.findElement(By.cssSelector("#isWhatsAppSubscription"));
		Updates.click();
		
		driver.findElement(By.xpath("//*[@id=\"story-popup-donate-button\"]")).click();
		
	}
	
	// Registration without providing Name field
	
	@Test
	 public void NameTest()
	 {
		FullName=driver.findElement(By.xpath("//input[contains(@id,'full_name')]"));
		FullName.sendKeys("");
		
		Email=driver.findElement(By.xpath("//*[@id=\"email_receipt\"]"));
    	Email.sendKeys("imapctguru@gmail.com");
    	
    	PhoneNumber=driver.findElement(By.xpath("//*[@id=\"mobile\"]"));
		PhoneNumber.sendKeys("1234567891");
		
		BillingCity=driver.findElement(By.xpath("//*[@id=\"city_text\"]"));
		BillingCity.sendKeys("Mumbai");
		
		Updates = driver.findElement(By.cssSelector("#isWhatsAppSubscription"));
		Updates.click();
		
		driver.findElement(By.xpath("//*[@id=\"story-popup-donate-button\"]")).click();		
		String expectedErrorMsg = "full_name";
		WebElement exp = driver.findElement(By.xpath("//input[contains(@id,'full_name')]"));
		String actualErrorMsg = exp.getText();
		Assert.assertEquals(actualErrorMsg, expectedErrorMsg);
		
		
	 }


	@Test
	 public void EmaiTest()
	 {
		FullName=driver.findElement(By.xpath("//input[contains(@id,'full_name')]"));
		FullName.sendKeys("");
		
		Email=driver.findElement(By.xpath("//*[@id=\"email_receipt\"]"));
   	Email.sendKeys("imapctguru@gmail.com");
   	
   	PhoneNumber=driver.findElement(By.xpath("//*[@id=\"mobile\"]"));
		PhoneNumber.sendKeys("1234567891");
		
		BillingCity=driver.findElement(By.xpath("//*[@id=\"city_text\"]"));
		BillingCity.sendKeys("Mumbai");
		
		Updates = driver.findElement(By.cssSelector("#isWhatsAppSubscription"));
		Updates.click();
		
		String expectedErrorMsg2 = "Please enter your Email";

		WebElement exp1 = driver.findElement(By.name("email_receipt,'Please enter your Email')]"));
		String actualErrorMsg2 = exp1.getText();

		Assert.assertEquals(actualErrorMsg2, expectedErrorMsg2);

		
		
	 }

	
	
	@Test
	 public void PhoneNumber()
	 {
		FullName=driver.findElement(By.xpath("//input[contains(@id,'full_name')]"));
		FullName.sendKeys("");
		
		Email=driver.findElement(By.xpath("//*[@id=\"email_receipt\"]"));
  	Email.sendKeys("imapctguru@gmail.com");
  	
  	PhoneNumber=driver.findElement(By.xpath("//*[@id=\"mobile\"]"));
		PhoneNumber.sendKeys("1234567891");
		
		BillingCity=driver.findElement(By.xpath("//*[@id=\"city_text\"]"));
		BillingCity.sendKeys("Mumbai");
		
		Updates = driver.findElement(By.cssSelector("#isWhatsAppSubscription"));
		Updates.click();
		
		
	
		String expectedErrorMsg4 = "The phone field is required.";
		
		WebElement exp4 = driver.findElement(By.name("mobile,'The phone field is required.')]"));
			String actualErrorMsg4 = exp4.getText();
	
		Assert.assertEquals(actualErrorMsg4, expectedErrorMsg4);
		

		
		
		
	 }
		
	@Test
	 public void BillingCity()
	 {
		FullName=driver.findElement(By.xpath("//input[contains(@id,'full_name')]"));
		FullName.sendKeys("");
		
		Email=driver.findElement(By.xpath("//*[@id=\"email_receipt\"]"));
 	Email.sendKeys("imapctguru@gmail.com");
 	
 	PhoneNumber=driver.findElement(By.xpath("//*[@id=\"mobile\"]"));
		PhoneNumber.sendKeys("1234567891");
		
		BillingCity=driver.findElement(By.xpath("//*[@id=\"city_text\"]"));
		BillingCity.sendKeys("Mumbai");
		
		Updates = driver.findElement(By.cssSelector("#isWhatsAppSubscription"));
		Updates.click();
		
		
	
		String expectedErrorMsg4 = "The phone field is required.";
		
		WebElement exp4 = driver.findElement(By.xpath(""));
			String actualErrorMsg4 = exp4.getText();
	
		Assert.assertEquals(actualErrorMsg4, expectedErrorMsg4);
		

		
		
		
	 }
	
	@Test
	 public void Checkbox()
	 {
		FullName=driver.findElement(By.xpath("//input[contains(@id,'full_name')]"));
		FullName.sendKeys("");
		
		Email=driver.findElement(By.xpath("//*[@id=\"email_receipt\"]"));
	Email.sendKeys("imapctguru@gmail.com");
	
	PhoneNumber=driver.findElement(By.xpath("//*[@id=\"mobile\"]"));
		PhoneNumber.sendKeys("1234567891");
		
		BillingCity=driver.findElement(By.xpath("//*[@id=\"city_text\"]"));
		BillingCity.sendKeys("Mumbai");
		
		Updates = driver.findElement(By.cssSelector("#isWhatsAppSubscription"));
		Updates.click();
		
		
	
		if (!Updates.isSelected()) {
			Updates.click();

		}
		Assert.assertTrue(Updates.isSelected(), "The checkbox is not selected.");
		
		
		
	 }
	
	

		


		
//
//
////	
////
////
	
//
//
		
//

		
////
////		
//
//
//
		
	//	
//
		
////		
////		try {
////			Thread.sleep(2000);
////		} catch (InterruptedException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////
////	}
////	
//
////





	@AfterClass()
	public void afterClass() {
		/* Close browser tab and session */
		driver.close();
		driver.quit();
	}

}
